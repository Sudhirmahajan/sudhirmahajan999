package com.nt.dao;

import java.util.List;

import com.nt.domain.Employee;

public interface EmployeeDAO {
   public List<Employee> getAllEmployees();
}
