package com.nt.dao;
public interface StudentDAO {
	
	public  int  updateStudentAddrsByNo(int no,String newAddrs);

}
