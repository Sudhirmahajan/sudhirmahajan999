package com.nt.service;

public interface StudentService {
  public String modifyStudentAddrsByNo(int no,String newAddrs);	
}
