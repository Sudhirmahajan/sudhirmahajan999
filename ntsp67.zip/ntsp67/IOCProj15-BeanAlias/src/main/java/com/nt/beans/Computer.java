package com.nt.beans;

public class Computer {
	
	public Computer() {
		System.out.println("Computer:0-param constructor");
	}

	@Override
	public String toString() {
		return "Computer fully loaded";
	}
	
	

}
