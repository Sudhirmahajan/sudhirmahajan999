package com.nt.vo;

public class EmployeeVO {
	private String eno;
	private String ename;
	private String eadd;
	private String bSalary;
	public String getEno() {
		return eno;
	}
	public void setEno(String eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEadd() {
		return eadd;
	}
	public void setEadd(String eadd) {
		this.eadd = eadd;
	}
	public String getBSalary() {
		return bSalary;
	}
	public void setBSalary(String bSalary) {
		this.bSalary = bSalary;
	}

}
