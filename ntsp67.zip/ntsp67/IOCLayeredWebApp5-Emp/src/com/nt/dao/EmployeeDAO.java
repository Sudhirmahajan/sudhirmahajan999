package com.nt.dao;

import com.nt.bo.EmployeeBO;

public interface EmployeeDAO {
	public int insert(EmployeeBO bo)throws Exception;

}
