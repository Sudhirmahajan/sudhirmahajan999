package com.nt.service;

public interface IntrAmountCalculator {
	
	public float calcIntrAmount(float pAmt,float rate,float time);

}
