package com.nt.service;

public class ShoppingStore {
	
	public float shopping(String [] items){
		return 2000*items.length;
	}//method
}//class
