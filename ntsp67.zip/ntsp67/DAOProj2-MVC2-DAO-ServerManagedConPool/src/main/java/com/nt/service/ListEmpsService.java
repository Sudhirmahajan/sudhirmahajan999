package com.nt.service;

import java.util.List;
import java.util.Map;

public interface ListEmpsService {
	
	public List<Map<String,Object>> searchEmpsByDesg(String desg[]);

}
