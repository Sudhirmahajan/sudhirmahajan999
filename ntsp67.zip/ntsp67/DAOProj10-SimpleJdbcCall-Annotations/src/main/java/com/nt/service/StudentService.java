package com.nt.service;

import com.nt.dto.StudentDTO;

public interface StudentService {
	public StudentDTO  searchStudentByNo(int no);

}
