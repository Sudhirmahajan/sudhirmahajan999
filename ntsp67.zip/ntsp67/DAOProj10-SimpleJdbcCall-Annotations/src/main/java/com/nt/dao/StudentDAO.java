package com.nt.dao;

import com.nt.bo.StudentBO;

public interface StudentDAO {
   public StudentBO  getStudentDetailsByNo(int no);
}
