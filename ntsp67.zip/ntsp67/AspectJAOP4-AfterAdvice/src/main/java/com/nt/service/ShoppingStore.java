package com.nt.service;

public class ShoppingStore {

	public float shopping(String []items){
		return items.length*2000;
	}
}
