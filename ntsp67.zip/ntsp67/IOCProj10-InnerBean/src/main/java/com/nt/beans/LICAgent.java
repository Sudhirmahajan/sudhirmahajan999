package com.nt.beans;

public class LICAgent {
	private int no;
	private String name;
	
	public void setNo(int no) {
		this.no = no;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "LICAgent [no=" + no + ", name=" + name + "]";
	}
	
	

}
