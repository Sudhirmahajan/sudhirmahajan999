package com.nt.aspect;

public class WrongBillInfoException extends RuntimeException {
	
	public WrongBillInfoException(String msg) {
		super(msg);
	}

}
