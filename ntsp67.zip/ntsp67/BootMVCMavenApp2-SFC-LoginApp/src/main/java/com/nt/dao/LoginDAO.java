package com.nt.dao;

import com.nt.domain.User;

public interface LoginDAO {
	
	public long  validate(User user);

}
