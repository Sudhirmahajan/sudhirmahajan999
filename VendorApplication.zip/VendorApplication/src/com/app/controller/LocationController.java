package com.app.controller;

import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.model.Location;
import com.app.service.ILocationService;
import com.app.util.LocationUtil;
import com.app.validator.LocationValidator;

@Controller
public class LocationController {
	@Autowired
	private ILocationService service;
@Autowired
	private ServletContext context;
@Autowired
private LocationUtil util;
@Autowired
private LocationValidator validator;

	@RequestMapping("/reg_location")
	public String showHome() {
		return "reg_location";
	}

	/**
	 * Read From Data From Form And Convert into Object Using ModelAttribute and
	 * process on Object And send View Name For Ui Page
	 */

	@RequestMapping(value = "/insertLoc", method = RequestMethod.POST)
	public String saveLocation(@ModelAttribute("location") Location loc,
			ModelMap map) {
		int locId = 0;
		String msg = null,errMsg=null;
		errMsg=validator.doLocationValidate(loc.getLocName());
		if(!"".equals(errMsg)){
			map.addAttribute("errMsg", errMsg);
		}
		else{
		// use Service class
		locId = service.saveLocation(loc);
		// prepare String Msg
		msg = "Save Dat By Id::" + locId;
		// add Value into ModelMap
		map.addAttribute("msg", msg);
		}
		return "reg_location";
	}// method

	/**
	 * Get All Location From DB Through Service and DAL
	 * 
	 * 
	 */
	@RequestMapping("/listAllLoc")
	public String showAllLocs(ModelMap map) {

		List<Location> listLoc = service.getAllLocs();
		map.addAttribute("listLoc", listLoc);
		return "load_all_location";
	}

	/**
	 * Delete Operation
	 * 
	 * 
	 */
	@RequestMapping("/deleteLoc")
	public String deleteLoc(@RequestParam("locId") int locId,ModelMap map) {
		String page="";
		String dMsg=validator.isLocationUsesByVendor(locId);
		if(!"".equals(dMsg)){
			List<Location> listLoc = service.getAllLocs();
			map.addAttribute("listLoc", listLoc);
			map.addAttribute("dMsg", dMsg);
			page="load_all_location";
		}
		else{
		// call Service
		service.deleteLocById(locId);
		page="redirect:listAllLoc";
		}
		return page;
	}

	/**
	 * Operation Perform to get Location Object by the given of locId
	 * 
	 * @param locId
	 * @param map
	 * @return
	 */

	@RequestMapping("/updateLoc")
	public String showEditLocation(@RequestParam("locId") int locId,
			ModelMap map) {
		Location loc = service.getLocationById(locId);
		map.addAttribute("locObj", loc);
		return "location_edit";
	}

	/**
	 * Update Operation Perform by the given Object
	 * 
	 */
	@RequestMapping(value = "/updateLocation", method = RequestMethod.POST)
	public String updateLocation(@ModelAttribute("location") Location loc) {
		service.updateLocation(loc);
		return "redirect:listAllLoc";
	}//method
	
	/**
	 * Export Excel View 
	 * 
	 */
	@RequestMapping("/exportExcelLoc")
	public String exportAllLocation(ModelMap map){
		List<Location> listLoc=service.getAllLocs();
		//add listObj In ModelMap
		map.addAttribute("listLocObj", listLoc);
		return "locExcel";
	}//method

	/**
	 * Export Pdf View 
	 * 
	 */
	@RequestMapping("/exportPdfLoc")
	public String getAllLocationInPdf(ModelMap map){
		List<Location> listLoc=service.getAllLocs();
		//add listObj In ModelMap
		map.addAttribute("listLocObj", listLoc);
		return "locPdf";
	}//method
	
	@RequestMapping("/viewLocationReport")
	public String getLocTypeByCount(){
		List<Object[]> list=service.getLocTypeByCount();
		String path=context.getRealPath("/");
		util.generatePieCart(path, list);
		util.getLocationBarChart(path, list);
		return "report_location";
	}
}// class
