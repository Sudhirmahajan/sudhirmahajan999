package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoginController {
	
	
	/**
	 * @author RANJAN
	 * @since 30/5/2017
	 * @return
	 */
	@RequestMapping("/login")
	public String showLoginPage(){
		return "login";
	}
	/**
	 * @author RANJAN
	 * @since 30/5/2017
	 * @return
	 */
	@RequestMapping("/description")
	public String showDescriptionPage(){
		return "aboutus";
	}

	
	/**
	 * 
	 * @param uname
	 * @param pwd
	 * @return
	 */
	@RequestMapping(value="/loginCheck",method=RequestMethod.POST)
	public String validationCheck(@RequestParam("userName")String uname,@RequestParam("pwd")String pwd ,ModelMap map){
		if(uname.equalsIgnoreCase("ranjan")&&pwd.equals("ranjan")){
			return "regUser";
		}
		else{
			map.addAttribute("msg","Invalid User");
			return "login";	
		}
		
	}
	
}
