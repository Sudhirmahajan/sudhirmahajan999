package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.app.model.Location;
import com.app.model.Vendor;
import com.app.service.IVendorService;
import com.app.util.CommonUtil;
import com.app.util.LocationUtil;
import com.app.validator.VendorValidator;

/**
 * @author RANJAN
 *
 */
@Controller
public class VendorController {
	@Autowired	
	private IVendorService service;
	@Autowired
	private LocationUtil locUtil;
	@Autowired
	private CommonUtil util;
	@Autowired
	private VendorValidator validator;
	
	/**
	 * 
	 * Home page Generator
	 */
	@RequestMapping("/reg_Home")
	public String home(){
		
		return "welcome";
	}
	
	
	/**
	 * 
	 * RegVendor page Generator
	 * @param map
	 * @return
	 */
	
	@RequestMapping("/reg_vendor")
	public String homePage( ModelMap map){
		List<Location> listLoc=locUtil.getAllLocation();
		map.addAttribute("listLocObj", listLoc);
		return "reg_vendor";
	}

	/**
	 * 
	 * Home Page Creation
	 */
	@RequestMapping("/home")
	public String welcomePage(){
		return "welcome";
	}

	/**
	 * Save Data Into Data base Through Service Layer and DataAccess Layer
	 */

	@RequestMapping(value="/venInsert",method=RequestMethod.POST)
	public String insertVendor(@ModelAttribute("vendor")Vendor ven,ModelMap map,@RequestParam("fObj")CommonsMultipartFile file){

		String eMsg="",mMsg="";
		eMsg=validator.isEmailExist(ven.getVenEmail());
		mMsg=validator.isMobileExist(ven.getVenMobile());
		//validate email exist or not
		if(!"".equals(eMsg)){
			List<Location> listLoc=locUtil.getAllLocation();
			map.addAttribute("listLocObj", listLoc);
		map.addAttribute("eMsg", eMsg);
		}
	 if(!"".equals(mMsg)){
			List<Location> listLoc=locUtil.getAllLocation();
			map.addAttribute("listLocObj", listLoc);
			map.addAttribute("mMsg", mMsg);
		}
		else{
		//Call Service Method
		int venId=	service.saveVendor(ven);
		//Create Msg 
		String msg="Data Save By Id: "+venId;
		//Set VenId Into ModelMap
		map.addAttribute("msg", msg);
		//Send Mail To Given Email Address
		util.sendEmail(ven.getVenEmail(), "Vendor Registration Verification", "ThankYou For Registring Vendor ManagementSystem VendorId:"+ven.getVenId(), file);
		
		//Set Location Object Into ModelMap
		List<Location> listLoc=locUtil.getAllLocation();
		map.addAttribute("listLocObj", listLoc);
		}
		return "reg_vendor";
	}
	/**
	 * Load All Vendor From DB TAble
	 * 
	 */
	@RequestMapping("/load_vendor")
	public String loadAllData(ModelMap map){

		List<Vendor> listVendor=service.getAllVendors();
		map.addAttribute("listVendor", listVendor);
		return "load_all_ven_list";
	}

	/**
	 * Delete Vendor By Id
	 */

	@RequestMapping("/ven_delete")
	public String deleteVendorById(@RequestParam("venId") int venId){

		service.deleteVendor(venId);
		return "redirect:load_vendor";
	}
	/**
	 * Get Vendor object for To Print In UI page
	 */
	@RequestMapping("/ven_update")
	public String getVendorById(@RequestParam("venId")int venId,ModelMap map){
		//call Service Method
		Vendor ven=service.getVendorById(venId);
		//Get Location Object
		List<Location> listLoc=locUtil.getAllLocation();
		//Add To Model Attribute
		map.addAttribute("venObj", ven);
		map.addAttribute("listLocObj", listLoc);
		return "vendor_edit";
	}
	/**
	 * Update Operation Perform
	 */

	@RequestMapping(value="/venUpdate",method=RequestMethod.POST)
	public String updateVendor(@ModelAttribute("vendor") Vendor ven){
		//call Service Method
		service.updateVendor(ven);
		return "redirect:load_vendor";
	}

	/**
	 * Export Excel  Operation Perform
	 */

	@RequestMapping("/venExcel")
	public String getAllVendorInExcel(ModelMap map){
		List<Vendor> listVen=service.getAllVendors();
		//Add To ModelMap
		map.addAttribute("listVenObj", listVen);
		return "venExcel";	
	}
	/**
	 * Export Pdf  Operation Perform
	 */

	@RequestMapping("/venPdf")
	public String getAllVendorInPdf(ModelMap map){
		List<Vendor> listVen=service.getAllVendors();
		//Add To ModelMap
		map.addAttribute("listVenObj", listVen);
		return "venPdf";	
	}
}
