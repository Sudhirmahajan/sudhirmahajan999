package com.app.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.model.User;
import com.app.service.IUserService;
import com.app.util.CoDecUtil;
import com.app.util.CodeUtil;
import com.app.util.CommonUtil;

@Controller
public class UserController {

	@Autowired
	private IUserService service;
	@Autowired
	private CodeUtil codeUtil;
	@Autowired
	private CommonUtil commonUtil;
	@Autowired
	private CoDecUtil codecUtile;

	/**
	 * 1. Show user registration page
	 */
	@RequestMapping("showRegUserPage")
	public String showPage() {
		return "regUser";
	}
	/**
	 * 2. Show admin registration page
	 */
	@RequestMapping("showRegAdminPage")
	public String showAdminPage() {
		return "regAdmin";
	}

	/**
	 *3 Show Login page
	 */
	@RequestMapping("showLoginPage")
	public String showLoginPage() {
		return "login_page";
	}
	
	/**
	 * 4. Show Email  page for Forgot Password
	 */
	@RequestMapping("showForgotPage")
	public String showForgotPage(HttpServletRequest req) {
		
		HttpSession ses=req.getSession(false);
		
		
		int diffTime=new Date(System.currentTimeMillis()).getMinutes()-new Date(ses.getCreationTime()).getMinutes();
		if(diffTime<0){
			diffTime=-1*diffTime;
		}
		if(diffTime>2){
			ses.setAttribute("otpNo", null);
			ses.invalidate();
		}
		return "user_email";
	}

	/**
	 * 5. Show Show welcome page
	 */
	@RequestMapping("showWelcome")
	public String showWelcomePage() {
		return "welcome";
	}
	
	
	/**
	 * 5 A.
	 * @param email
	 * @return ShowPasswordPage
	 */
	@RequestMapping(value="showPasswordPage")
	public String changPassword(@RequestParam("email")String email,ModelMap map){
		
		List<User> user=service.getUserByEmail(email);
		//Get Id
		int userId=user.get(0).getUserId();
		//add To map
		map.addAttribute("userId", userId);
		return "showPasswordPage";
	}
	
	/**
	 * 6. Save Operation Perform
	 */
	@RequestMapping(value = "inserUser", method = RequestMethod.POST)
	public String userRegistration(@ModelAttribute("user") User user, ModelMap map) {
		int userId = 0;
		String name = "", pwd = "", encPwd = "", text = "", userPage = "";
		String msg = null;
		// generate User password
		name = user.getUserName().substring(0, 3).toUpperCase();
		pwd = name + codeUtil.genPwd();
		// encrypt password
		encPwd = codecUtile.doEncode(pwd);
		// setUserPwd into Object
		user.setUserPwd(encPwd);
		if ("admin".equalsIgnoreCase(user.getUserType())) {
			user.setStatus(1);
		}
		// save operation perform using service method
		userId = service.saveUser(user);
		if (userId <= 0 && "admin".equalsIgnoreCase(user.getUserType())) {
			// add to model map
			msg = "Register Failed with Id:";
			map.addAttribute("msg", msg + userId + "Try After some Time");
			userPage = "regAdmin";
		}
		if (userId <= 0 && "user".equalsIgnoreCase(user.getUserType())) {
			// add to model map
			msg = "Register Failed with Id:";
			map.addAttribute("msg", msg + userId);
			userPage = "regUser";
		} else {
			// add to model map
			msg = "Register Successful with Id:";
			map.addAttribute("msg", msg + userId);
		}
		// send Email into register user

		if (userId > 0 && "admin".equalsIgnoreCase(user.getUserType())) {
			text = "UserName::" + user.getUserEmail() + " \r\n \r\n Password::" + pwd;
			commonUtil.sendEmailWithoutAttachment(user.getUserEmail(), "User Registratin Successful", text);
		} else  if (userId > 0 && "user".equalsIgnoreCase(user.getUserType())){
			text = "UserName::" + user.getUserEmail() + " \r\n \r\n Password::" + pwd
					+ "\r\n \r\n wait for admin approval";
			commonUtil.sendEmailWithoutAttachment(user.getUserEmail(), "User Registratin Successful", text);
		}
		return userPage;
	}

	/**
	 *7 .
	 * read UserName and Password through Request parameter load user object
	 * given by userName get encoded password from dbTable Decode Password and
	 * validate given password with decoded password create session object and
	 * set userName into session scope return view page
	 */
	@RequestMapping(value = "loginUser", method = RequestMethod.POST)
	public String isUserName(@RequestParam("userName") String un, @RequestParam("pwd") String pwd,
			@RequestParam("type") String type, ModelMap map, HttpServletRequest req) {

		User user = null;
		String pageName = "", encPwd = "", password = "";
		// call Service Method
		user = service.getUserByUserName(un,type);		
		if (user == null) {
			map.addAttribute("msg", "Invalid UserName/UserType");
			return "login_page";
		}
		else {
			encPwd = user.getUserPwd();
			// decode Encoded Password using CodecUtil
			password = codecUtile.doDecode(encPwd);
			if (!password.equals(pwd) ) {
				map.addAttribute("msg", "Invalid UserName/Password");
				return "login_page";
			}		
			if ("admin".equalsIgnoreCase(type)) {
				List<User> list = service.getAllUser();
				map.addAttribute("list", list);
				map.addAttribute("user",list.get(0).getUserEmail());
				pageName = "admin_page";
			} else if ("user".equalsIgnoreCase(type) && user.getStatus() == 0) {
				map.addAttribute("msg", "Wait for admin approval");
				pageName = "login_page";
			} else {
				map.addAttribute("user", user.getUserEmail());
				pageName = "welcomeUser";
			}		
		}
		HttpSession ses = req.getSession();
		ses.setAttribute("userName", user.getUserName());	
		return pageName;
	}

	/**
	 * 8. Logout action perform read session attribute value and invalidate
	 * session display and return into login page
	 * 
	 */
	@RequestMapping("/logout")
	public String logoutUser(HttpServletRequest req, ModelMap map) {
		HttpSession ses=req.getSession(false);
		ses.setAttribute("userName", null);
		req.setAttribute("otpNo", null);
		ses.invalidate();
		//System.out.println(ses.getAttribute("userName"));
		map.addAttribute("msg", "Logout Successful");
		return "login_page";
	}

	/**
	 * 9.
	 * @param map
	 * @return List of user
	 */
	@RequestMapping("showAllUser")
	public String LoadAllUser(ModelMap map) {
		List<User> list = service.getAllUser();
		map.addAttribute("list", list);
		return "load_all_user";
	}

	/**
	 * 10.
	 *  Change of User Status
	 * Using UserId and Status code
	 */
	@RequestMapping("editPage")
	public String changeStatus(@RequestParam("uid") int uid, @RequestParam("status") int status) {
		User user = null;
		service.changeStatus(uid, status);
		// get User by id
		user = service.getUserById(uid);
		int stats = user.getStatus();
		// send message into user email
		if (stats == 0) {
			return "redirect:showAllUser";
		} else {
			String text = "Your acount is activate now you are able to  Login";
			commonUtil.sendEmailWithoutAttachment(user.getUserEmail(), "Thank you for Registration", text);
		}
		return "redirect:showAllUser";
	}//method
	
	/**
	 * 11.
	 * @param mail
	 * @param map
	 * @param req
	 * @return  OtpPage
	 */
	@RequestMapping(value="showOtpPage")
	public String getUserPasswordByEmailOrPassword(@RequestParam("email")String mail,ModelMap map,HttpServletRequest req){
		List<User> userList=null;
		//call Service method
		userList=service.getUserByEmail(mail);
		if(userList.size()==0){
			map.addAttribute("msg", "Email Addres not find");
			return "user_email";
		}
		Random rad=new Random();
		int otp=10000+rad.nextInt(10000);
		HttpSession ses=req.getSession(true);
		ses.setAttribute("otpNo", otp);
		commonUtil.sendEmailWithoutAttachment(mail, "Your Otp is:",""+otp);
		
		//map.addAttribute("user", userList.get(0).getUserId());
		map.addAttribute("user", userList.get(0).getUserEmail());
		return "otp_check";
	}
	
	/**
	 *12. 
	 * @param otp
	 * @param email
	 * @param req
	 * @param map
	 * @return Password Page
	 */
	@RequestMapping(value="showResetPassword",method=RequestMethod.POST)
	public String generatePasswordPage(@RequestParam("otp")String otp,
												@RequestParam("email")String email,HttpServletRequest req,ModelMap map){
		HttpSession ses=req.getSession(false);
		String otpNo="";
		int diffTime=new Date(System.currentTimeMillis()).getMinutes()-new Date(ses.getCreationTime()).getMinutes();
		if(diffTime<0){
			diffTime=-1*diffTime;
		}
		System.out.println(diffTime);
		if(diffTime>2){
			ses.setAttribute("otpNo", null);
			ses.invalidate();
		}
		try{
		if(ses.getAttribute("otpNo")!=null){
		otpNo= ses.getAttribute("otpNo").toString();
		if(!otpNo.equals(otp)){
			map.addAttribute("msg","please provide valid otp number");
			map.addAttribute("user",email);
			return "otp_check";
		}
		List<User> userList=service.getUserByEmail(email);
		map.addAttribute("user", userList.get(0).getUserId());
		return "passwordPage";
		}
		}
		catch(Exception e){
			map.addAttribute("msg","Your OtpNo  Expire Try Again To Generate Otp");
		return "user_email";
		}
		return "passwordPage";
	}//method
		
	/**
	 * 13
	 * @param pwd
	 * @param uid
	 * @return ViewName
	 */
	@RequestMapping(value="resetPassword",method=RequestMethod.POST)
	public String resetPassword(@RequestParam("pwd")String pwd,@RequestParam("id")int uid,ModelMap map){
		
		String encpwd="";
		encpwd=codecUtile.doEncode(pwd);
		
	String email=service.chanPassword(uid, encpwd);
		commonUtil.sendEmailWithoutAttachment(email, "Password Change", "Your Password Will be change \r\n Your new Password is:"+pwd);
		map.addAttribute("msg", "Your Passwod change Successfully");
		return "login_page";
	}
	
	/**
	 * 14
	 * @param pwd
	 * @param uid
	 * @param currPwd
	 * @return ViewName
	 */
	@RequestMapping(value="changePassword",method=RequestMethod.POST)
	public String changPassword(@RequestParam("pwd")String pwd,@RequestParam("id")int uid,@RequestParam("currpwd")String currpwd,ModelMap map){
		
		String encpwd="",currEncPwd="",pass="";
		User user=service.getUserById(uid);
		//get current encoded user password 
		currEncPwd=user.getUserPwd();
		//convert to decoded
		pass=codecUtile.doDecode(currEncPwd);
		
		
		if(pass.equals(currpwd)){
		encpwd=codecUtile.doEncode(pwd);
		
	String email=service.chanPassword(uid, encpwd);
		commonUtil.sendEmailWithoutAttachment(email, "Password Change", "Your Password Will be change \r\n Your new Password is:"+pwd);
		map.addAttribute("msg", "Your Passwod change Successfully");
		return "login_page";
		}
		else{
			map.addAttribute("userId", uid);
			map.addAttribute("msg" ,"You Enter Wrong Current password");
			return "showPasswordPage";
		}
	}
	
}//class
