package com.app.controller.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.app.model.Customer;
import com.app.model.Location;
import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class CustomerPdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> map, Document doc, PdfWriter arg2, HttpServletRequest arg3,
			HttpServletResponse arg4) throws Exception {
		@SuppressWarnings("unchecked")
		List<Customer> listCust = (List<Customer>) map.get("listCustObj");
		PdfPTable table = new PdfPTable(8);
		table.addCell("ID");
		table.addCell("Name");
		table.addCell("Mail");
		table.addCell("Type");
		table.addCell("Address");
		table.addCell("Token");
		table.addCell("LocationName");
		table.addCell("LocationName");
		for (Customer cust : listCust) {
			table.addCell("" + cust.getCustId());
			table.addCell(cust.getCustName());
			table.addCell(cust.getCustEmail());
			table.addCell(cust.getCustType());
			table.addCell(cust.getCustAdd());
			table.addCell(cust.getAccToken());
			table.addCell(cust.getLoc().getLocName());
			table.addCell(cust.getLoc().getLocType());
		} // For
		Paragraph p = new Paragraph();
		doc.addTitle("Location PDF Sample");
		doc.add(p);
		doc.add(table);

	}// Method

}
