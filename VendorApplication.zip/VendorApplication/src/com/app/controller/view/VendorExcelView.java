package com.app.controller.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.app.model.Vendor;

public class VendorExcelView extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> map, HSSFWorkbook book, HttpServletRequest arg2,
			HttpServletResponse arg3) throws Exception {
		HSSFSheet sheet=book.createSheet("Customer");
		@SuppressWarnings("unchecked")
		List<Vendor> listVen=(List<Vendor>) map.get("listVenObj");
		getHeader(sheet);
		setRows(sheet, listVen);
	}
private void getHeader(HSSFSheet sheet){
	
	HSSFRow row=sheet.createRow(0);
	row.createCell(0).setCellValue("ID");
	row.createCell(1).setCellValue("Name");
	row.createCell(2).setCellValue("Mail");
	row.createCell(3).setCellValue("Mobile");
	row.createCell(4).setCellValue("Address");
	row.createCell(5).setCellValue("LocationName");
	row.createCell(6).setCellValue("LocationType");
}

private void setRows(HSSFSheet sheet,List<Vendor> listVen){
	int rowCount=1;
	for(Vendor ven:listVen){
		HSSFRow row=sheet.createRow(rowCount++);
		row.createCell(0).setCellValue(ven.getVenId());
		row.createCell(1).setCellValue(ven.getVenName());
		row.createCell(2).setCellValue(ven.getVenEmail());
		row.createCell(3).setCellValue(ven.getVenMobile());
		row.createCell(4).setCellValue(ven.getVenAddress());
		row.createCell(5).setCellValue(ven.getLoc().getLocName());
		row.createCell(6).setCellValue(ven.getLoc().getLocType());
	}
}
}
