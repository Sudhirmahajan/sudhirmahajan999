package com.app.controller.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.tribes.group.GroupChannel.HeartbeatThread;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.app.model.Customer;

public class CustomerExcelView extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> map, HSSFWorkbook book, HttpServletRequest arg2,
			HttpServletResponse arg3) throws Exception {
		HSSFSheet sheet = book.createSheet("Customer");
		List<Customer> listCust = (List<Customer>) map.get("listCustObj");
		getHeader(sheet);
		setRows(sheet, listCust);
	}

	private void getHeader(HSSFSheet sheet) {

		HSSFRow row = sheet.createRow(0);
		row.createCell(0).setCellValue("ID");
		row.createCell(1).setCellValue("Name");
		row.createCell(2).setCellValue("Mail");
		row.createCell(3).setCellValue("Type");
		row.createCell(4).setCellValue("Address");
		row.createCell(5).setCellValue("Token");
		row.createCell(6).setCellValue("LocationName");
		row.createCell(7).setCellValue("LocationType");
	}

	private void setRows(HSSFSheet sheet, List<Customer> listCust) {
		int rowCount = 1;
		for (Customer cust : listCust) {
			HSSFRow row = sheet.createRow(rowCount++);
			row.createCell(0).setCellValue(cust.getCustId());
			row.createCell(1).setCellValue(cust.getCustName());
			row.createCell(2).setCellValue(cust.getCustEmail());
			row.createCell(3).setCellValue(cust.getCustType());
			row.createCell(4).setCellValue(cust.getCustAdd());
			row.createCell(5).setCellValue(cust.getAccToken());
			row.createCell(6).setCellValue(cust.getLoc().getLocName());
			row.createCell(7).setCellValue(cust.getLoc().getLocType());
		}
	}
}
