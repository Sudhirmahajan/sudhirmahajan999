package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.model.Customer;
import com.app.model.Item;
import com.app.model.Location;
import com.app.model.Transaction;
import com.app.service.ICustomerService;
import com.app.util.CoDecUtil;
import com.app.util.CodeUtil;
import com.app.util.CommonUtil;
import com.app.util.LocationUtil;
import com.app.validator.CustomerValidator;

@Controller
public class CustomerController {

	@Autowired
	private ICustomerService service;
	@Autowired
	private LocationUtil locUtil;
	@Autowired
	private CustomerValidator validator;
	@Autowired
	private CodeUtil codeUtil;
	@Autowired
	private CoDecUtil codecUtil;
	@Autowired
	private CommonUtil commonUtil;
	
	/**
	 * Show Ui Page For Customer Registration
	 * 
	 */
	@RequestMapping("/showCust")
	public String showRegCustPage(ModelMap map) {
		List<Location> listLoc=locUtil.getAllLocation();
		map.addAttribute("listLocObj", listLoc);
		return "reg_cust";
	}

	/**
	 * @author RANJAN
	 * @since 16/05/2017 Save Customer Data Using ModelAttribute
	 * @return View name
	 */
	@RequestMapping(value = "/saveCustomer", method = RequestMethod.POST)
	public String saveCustomerDetails(
			@ModelAttribute("customer") Customer cust, ModelMap map) {
		int id = 0;
		String pwd="",token="",ePwd="",eToken="";
		String name=cust.getCustName().substring(0, 3);
		//Generate Password And AccToken
		 pwd=name+codeUtil.genPwd();
		 token=name+codeUtil.genToken();
		//convert Normal Data into encoded Form
		ePwd=codecUtil.doEncode(pwd);
		eToken=codecUtil.doEncode(token);
		
		//set Values into Object
		cust.setAccToken(eToken);
		cust.setPassword(ePwd);
		
		//Validate email Exist Or not
		String eMsg="";
		eMsg=validator.isEmailExist(cust.getCustEmail());

		//validate email exist or not
		if(!"".equals(eMsg)){
			List<Location> listLoc=locUtil.getAllLocation();
			map.addAttribute("listLocObj", listLoc);
		map.addAttribute("eMsg", eMsg);
		}
		else{
		// call Service Method
		id = service.saveCustomer(cust);
		// add id Value To Model Map
		map.addAttribute("id","Registration Succeded With Customer Id::"+ id);
		List<Location> listLoc=locUtil.getAllLocation();
		map.addAttribute("listLocObj", listLoc);
		//Send Email
		String userDetails="UserName::"+cust.getCustEmail()+
				" \r\n  \r\n(Customer Type::"+cust.getCustType()+
				"\r\n  \r\n Password::"+pwd+
				" \r\n \r\n Access Token Number::"+token;
		commonUtil.sendEmailWithoutAttachment(cust.getCustEmail(), "Customer Registration", userDetails);
		}
	
		
		return "reg_cust";
	}

	/**
	 * @author RANJAN
	 * @since 16/05/2017 Load Customer Data Using ModelAttribute
	 */
	@RequestMapping("/listAllCustomer")
	public String loadAllCustomer(ModelMap map) {
		List<Customer> listCustomer = service.loadAllCustomer();
		// add listCustomer Object into ModelMap
		map.addAttribute("listCustObj", listCustomer);
		return "load_customer";
	}

	/**
	 * @author RANJAN
	 * @since 16/05/2017 Delete Customer Data Using RequestParam
	 */
	@RequestMapping("/deleteCustomer")
	public String deleteCustomerId(@RequestParam("custId") int custId) {
		service.deleteCustById(custId);
		return "redirect:listAllCustomer";
	}

	/**
	 * @author RANJAN
	 * @since 16/05/2017 Get Customer By Id
	 */
	@RequestMapping("/getCustById")
	public String getCustomerId(@RequestParam("custId") int custId, ModelMap map) {
		// call Service Method
		Customer cust = service.getCustById(custId);
		//load all Location Object
		List<Location> listLoc=locUtil.getAllLocation();
		// Add CustObject And Location Object Into Map
		map.addAttribute("custObj", cust);
		map.addAttribute("listLocObj", listLoc);
		return "edit_cutomer_page";
	}

	/**
	 * @author RANJAN
	 * @since 16/05/2017 Update Customer Data Using ModelAttribue
	 */
	@RequestMapping(value="/updateCustomer",method=RequestMethod.POST)
	public String updateCustomer(@ModelAttribute("customer") Customer cust) {
		service.updateCustomer(cust);
		return "redirect:listAllCustomer";
	}

	/**
	 * @author RANJAN
	 * @since 18/05/2017 Get All Customer Data Using ModelMap
	 */
	@RequestMapping("/excelCust")
	public String getAllCutomerInExcel(ModelMap map){
		List<Customer> listCust=service.loadAllCustomer();
		//add To ModelMap
		map.addAttribute("listCustObj", listCust);
		return "custExcel";
	}
	@RequestMapping("/pdfCust")
	public String getAllCutomerInPdf(ModelMap map){
		List<Customer> listCust=service.loadAllCustomer();
		//add To ModelMap
		map.addAttribute("listCustObj", listCust);
		return "custPdf";
	}

	/**
	 * Load all Item by Customer Id
	 */
@RequestMapping("showItem")
	public String loadAllItemById(@RequestParam("custId")int custId,ModelMap map){
		List<Item>listItem=service.loadAllItemByCustomerId(custId);
		//add Into  model map
		map.addAttribute("listItem", listItem);
		map.addAttribute("customerId", custId);
		
	return "show_item_list";
	}

/**
 * Load Transaction by Customer Id
 */
@RequestMapping("showTxn")
public String loadTxnById(@RequestParam("custId")int custId,ModelMap map){
	List<Transaction>listTxn=service.loadTxnByCustomerId(custId);
	//add Into  model map
	map.addAttribute("listTxn", listTxn);
	map.addAttribute("customerId", custId);
return "show_txn";
}
}
