package com.app.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.service.ILocationService;

@Component
public class LocationValidator {
@Autowired
	private ILocationService service;
	
	public String doLocationValidate(String locName){
		String msg="";
		if(service.isLocationNameExisted(locName)){
			msg="Name '"+locName+"'  Already Existed";
		}
		return msg;
	}
	
	public String isLocationUsesByVendor(int locId){
		String dMsg="";
		if(service.isDeletedLocationIdExisted(locId)){
			dMsg="This LocId '"+locId+"' Is Not Delete Because It Uses Some Ware ";
		}
		return dMsg;
	}
}
