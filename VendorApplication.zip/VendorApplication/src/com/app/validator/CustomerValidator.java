package com.app.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.model.Customer;
import com.app.service.ICustomerService;
import com.app.util.CoDecUtil;
@Component
public class CustomerValidator {

	@Autowired
	private ICustomerService service;
	@Autowired
	private CoDecUtil codecUtile;
	
	public String isEmailExist(String custEmail){
		String eMsg="";
		if(service.isEmailExisted(custEmail)){
			System.out.println(service.isEmailExisted(custEmail));
			eMsg="Email  All Ready Exist";
		}
		return eMsg;
	}
	
	public boolean isCustomerTypeSeller(Customer cust){
		return "saller".equalsIgnoreCase(cust.getCustType());
	}
	
	public boolean isCustomerTypeConsumer(Customer cust){
		
		return "consumer".equalsIgnoreCase(cust.getCustType());
	}
	
	public boolean isPwdAndTokenId(String reqPwd,String reqToken,Customer cust){
		String encPwd="",encToken="",dePwd="",deToken="";
		
		//get Encoded Password and Token From Database
		encPwd=cust.getPassword();
		encToken=cust.getAccToken();
		//Decode Password using CoDecUtil class
		dePwd=codecUtile.doDecode(encPwd);
		deToken=codecUtile.doDecode(encToken);
		return reqPwd.equals(dePwd)&&reqToken.equals(deToken);
	}
}
