package com.app.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.service.IVendorService;

@Component
public class VendorValidator {

	@Autowired
	private IVendorService service;
	
	public String isEmailExist(String venEmail){
		String eMsg="";
		if(service.isEmailExisted(venEmail)){
			eMsg="Email  All Ready Exist";
		}
		return eMsg;
	}
	public String isMobileExist(long venMobile){
		String eMsg="";
		if(service.isMobileExisted(venMobile)){
			eMsg="Mobile Number  All Ready Exist";
		}
		return eMsg;
	}
}
