package com.app.util;

import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Component;

@Component
public class CoDecUtil {

	public String doEncode(String nrml){
		byte[] bArr=Base64.encodeBase64(nrml.getBytes());
		return new String(bArr);
	}
	public String doDecode(String encStr){
		byte[] bArr=Base64.decodeBase64(encStr.getBytes());
		return new String(bArr);
	}
}
