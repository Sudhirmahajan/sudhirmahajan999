package com.app.util;

import java.io.IOException;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Component;

@Component
public class JsonUtil {
	private static ObjectMapper mapper=null;
	static{
		mapper=new ObjectMapper();
	}
	public String objectToJson(Object obj){
		String jsonStr=null;
		try {
			jsonStr = mapper.writeValueAsString(obj);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsonStr;
	}//ObjectToJson method

	public Object jsonToObject(String jsonStr,Class cls){
		Object responce=null;
		try {
			responce=mapper.readValue(jsonStr, cls);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return responce;
	}
	
}
