package com.app.util;

import java.io.IOException;
import java.io.InputStream;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Component
public class CommonUtil {
	
	@Autowired
	private JavaMailSender mailSender;
	
	public void sendEmail(String to,String sub,String text,final CommonsMultipartFile file){
	
		if(file!=null){
		try {
			MimeMessage message=mailSender.createMimeMessage();
			MimeMessageHelper helper=new MimeMessageHelper(message, true);
			helper.setTo(to);
			helper.setSubject(sub);
			helper.setText(text);
			helper.setFrom("ranjan007@gmail.com");
			helper.addAttachment(file.getOriginalFilename(),new InputStreamSource(){
				@Override
				public InputStream getInputStream() throws IOException {
					return file.getInputStream();
				}		
			});
			mailSender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		}//if		
	}//method
	
	public void sendEmailWithoutAttachment(String to,String sub,String text){
		
		try {
			MimeMessage message=mailSender.createMimeMessage();
			MimeMessageHelper helper=new MimeMessageHelper(message, true);
			helper.setTo(to);
			helper.setSubject(sub);
			helper.setText(text);;
			helper.setFrom("ranjan007@gmail.com");
			mailSender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}	
	}//method
}//class
