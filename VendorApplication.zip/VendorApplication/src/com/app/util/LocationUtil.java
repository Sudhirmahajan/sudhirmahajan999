package com.app.util;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.model.Location;
import com.app.service.ILocationService;

@Component
public class LocationUtil {

	@Autowired
	private ILocationService service;
	
	public List<Location> getAllLocation(){
		
		return service.getAllLocs();
	}

	public void generatePieCart(String path,List<Object[]> list){
		//convert To data Set
		DefaultPieDataset dataset=new DefaultPieDataset();
		//add Object into data Set
		for(Object[] ob:list){
			dataset.setValue(ob[0].toString(),new Double(ob[1].toString()));
		}
		//covert data set into JFreeChart 
		JFreeChart chart=ChartFactory.createPieChart3D("LocationReport", dataset, true,true, false);
	//convert To Image
		try {
			ChartUtilities.saveChartAsJPEG(new File(path+"/reportALoc.jpg"), chart, 400, 300);
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}//method
	
	public void getLocationBarChart(String path,List<Object[]> list){
		//convert Data Set
		DefaultCategoryDataset dataset=new DefaultCategoryDataset();
		
		//Add Object into dataSet
		for(Object[] ob:list){
			dataset.setValue(new Double(ob[1].toString()),ob[0].toString(), "");
		}
		//convert  JFreeChart obj
		JFreeChart chart=ChartFactory.createBarChart3D("Location Report", "Location Type", "Locaion Count", dataset);
		// Convert Jfree Chart to Image
		try {
			ChartUtilities.saveChartAsJPEG(new File(path+"/reportBLoc.jpg"), chart, 400, 300);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
