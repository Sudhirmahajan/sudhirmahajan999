package com.app.util;

import java.util.UUID;

import org.springframework.stereotype.Component;

@Component
public class CodeUtil {
private String getStr(int size){
	
	return UUID.randomUUID().toString().replaceAll("-","").substring(0,size);
}
public String genPwd(){
	return getStr(4);
}
public String genToken(){
	return getStr(4);
}
}
