package com.app.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SessionCheckFilter implements Filter {

	List<String> listUrls = null;

	public void init(FilterConfig fConfig) throws ServletException {
		StringTokenizer st = null;
		// get InitParameterValue
		String urls = fConfig.getInitParameter("avoid-urls");
		// create StringTokenizer
		st = new StringTokenizer(urls, ",");
		// create empty arrayList
		listUrls = new ArrayList<String>();
		while (st.hasMoreTokens()) {
			listUrls.add(st.nextToken());
		} // while
	}// init

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest hreq = null;
		HttpServletResponse hres = null;

		// type cast to request and response
		hreq = (HttpServletRequest) request;
		hres = (HttpServletResponse) response;

		// Cache clear when Logout
		hres.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		hres.setHeader("Pragma", "no-cache");
		hres.setDateHeader("Expires", 0);

		// read Current Request URI
		String uri = hreq.getRequestURI();

		// Check isUrls is Exist or not in List
		boolean flag = listUrls.contains(uri);
		try {
			// true mean do not check session
			// false means check session

			HttpSession ses = hreq.getSession(false);
			if (!flag) {
				if (ses == null || ses.getAttribute("userName") == null) {
					hres.sendRedirect(hreq.getContextPath() + "/mvc/showLoginPage");
					System.out.println(ses + "   " + ses.getAttribute("userName"));
				}
			} // flag if
		} catch (Exception e) {
		}

		// if Request is valid then continue
		chain.doFilter(request, response);
	}// doFilter(-,-)

	public void destroy() {

	}// destroy()

}// Filter Class
