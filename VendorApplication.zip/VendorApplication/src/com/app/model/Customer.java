package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="CustTab")
public class Customer implements Comparable<Customer> {

	@Id
	@Column(name="cid")
	private int custId;
	@Column(name="cname")
	private String custName;
	@Column(name="email")
	private String custEmail;
	@Column(name="type")
	private String custType;
	@Column(name="addr")
	private String custAdd;
	@Column(name="pwd")
	private String password;
	@Column(name="token")
	private String accToken;
	
	@ManyToOne
	@JoinColumn(name="locFk")
	private Location loc;
	
	public Customer() {
	}

	public Customer(int custId) {
		this.custId = custId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getCustAdd() {
		return custAdd;
	}

	public void setCustAdd(String custAdd) {
		this.custAdd = custAdd;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAccToken() {
		return accToken;
	}

	public void setAccToken(String accToken) {
		this.accToken = accToken;
	}

	public Location getLoc() {
		return loc;
	}

	public void setLoc(Location loc) {
		this.loc = loc;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName
				+ ", custEmail=" + custEmail + ", custType=" + custType
				+ ", custAdd=" + custAdd + ", password=" + password
				+ ", accToken=" + accToken + ", loc=" + loc + "]";
	}

	@Override
	public int compareTo(Customer o) {
		
		return this.custId-o.custId;
	}
	
	
}
