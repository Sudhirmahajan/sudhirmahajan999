package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

@Entity
@Table(name="txn_tab")
public class Transaction {

	@Id
	@Column(name="txnId")
	private int txnId;
	@Column(name="txnCustName")
	private String txnCustName;
	@Column(name="txnCost")
	private double txnCost;
	@Column(name="txnItem")
	private String txnItem;
	@Column(name="txnModel")
	private String txnModel;
	@Column(name="custId")
	@JsonIgnore
	private int custId;

	public int getTxnId() {
		return txnId;
	}
	public void setTxnId(int txnId) {
		this.txnId = txnId;
	}
	public String getTxnCustName() {
		return txnCustName;
	}
	public void setTxnCustName(String txnCustName) {
		this.txnCustName = txnCustName;
	}
	public double getTxnCost() {
		return txnCost;
	}
	public void setTxnCost(double txnCost) {
		this.txnCost = txnCost;
	}
	public String getTxnItem() {
		return txnItem;
	}
	public void setTxnItem(String txnItem) {
		this.txnItem = txnItem;
	}
	public String getTxnModel() {
		return txnModel;
	}
	public void setTxnModel(String txnModel) {
		this.txnModel = txnModel;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	@Override
	public String toString() {
		return "Transaction [txnId=" + txnId + ", txnCustName=" + txnCustName + ", txnCost=" + txnCost + ", txnItem="
				+ txnItem + ", txnModel=" + txnModel + ", custId=" + custId + "]";
	}
	
	
	
}
