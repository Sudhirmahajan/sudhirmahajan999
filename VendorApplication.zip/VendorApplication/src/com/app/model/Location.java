package com.app.model;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="loc_tab")
@Entity
public class Location implements Comparable<Location> {
	@Id
	@Column(name="lid")
	private int locId;
	@Column(name="lname")
	private String locName;
	@Column(name="ltype")
	private String locType;
	
	@Column(name="pincode")
	private String pincode;
	@Column(name="sType")
	private String shippingType;
	@Column(name="cDtails")
	private String contactDetail;
	@Column(name="pCode")
	private String processCode;
	
	@Column(name="transType")
	private String[] transportType;

	public Location() {
		super();
	}

	public Location(int locId) {
		super();
		this.locId = locId;
	}

	public int getLocId() {
		return locId;
	}

	public void setLocId(int locId) {
		this.locId = locId;
	}

	public String getLocName() {
		return locName;
	}

	public void setLocName(String locName) {
		this.locName = locName;
	}

	public String getLocType() {
		return locType;
	}

	public void setLocType(String locType) {
		this.locType = locType;
	}
@Override
public int compareTo(Location o) {
	return this.locId-o.locId;
}

public String getPincode() {
	return pincode;
}

public void setPincode(String pincode) {
	this.pincode = pincode;
}

public String getShippingType() {
	return shippingType;
}

public void setShippingType(String shippingType) {
	this.shippingType = shippingType;
}

public String getContactDetail() {
	return contactDetail;
}

public void setContactDetail(String contactDetail) {
	this.contactDetail = contactDetail;
}

public String getProcessCode() {
	return processCode;
}

public void setProcessCode(String processCode) {
	this.processCode = processCode;
}


public String[] getTransportType() {
	
	return transportType;
}

public void setTransportType(String[] transportType) {
	this.transportType = transportType;
}

@Override
public String toString() {
	return "Location [locId=" + locId + ", locName=" + locName + ", locType="
			+ locType + ", pincode=" + pincode + ", shippingType="
			+ shippingType + ", contactDetail=" + contactDetail
			+ ", processCode=" + processCode + ", transportType="
			+ Arrays.toString(transportType) + "]";
}
	

}
