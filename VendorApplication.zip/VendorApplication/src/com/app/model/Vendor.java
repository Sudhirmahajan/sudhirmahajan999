package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Table(name = "ventab")
@Entity
public class Vendor implements Comparable<Vendor> {
	@Id
	@Column(name = "vid")
	private int venId;
	@Column(name = "vn")
	private String venName;
	@Column(name = "vmail")
	private String venEmail;
	@Column(name = "mbl")
	private long venMobile;
	@Column(name = "ADDRESS")
	private String venAddress;

	@ManyToOne
	@JoinColumn(name="locFk")
	private Location loc;
	
	
	public Vendor() {

	}

	public Vendor(int venId) {

		this.venId = venId;
	}

	public int getVenId() {
		return venId;
	}

	public void setVenId(int venId) {
		this.venId = venId;
	}

	public String getVenName() {
		return venName;
	}

	public void setVenName(String venName) {
		this.venName = venName;
	}

	public String getVenEmail() {
		return venEmail;
	}

	public void setVenEmail(String venEmail) {
		this.venEmail = venEmail;
	}

	public long getVenMobile() {
		return venMobile;
	}

	public void setVenMobile(long venMobile) {
		this.venMobile = venMobile;
	}

	public String getVenAddress() {
		return venAddress;
	}

	public void setVenAddress(String venAddress) {
		this.venAddress = venAddress;
	}

	@Override
	public int compareTo(Vendor o) {

		return this.venId - o.venId;
	}

	public Location getLoc() {
		return loc;
	}

	public void setLoc(Location loc) {
		this.loc = loc;
	}

	@Override
	public String toString() {
		return "Vendor [venId=" + venId + ", venName=" + venName
				+ ", venEmail=" + venEmail + ", venMobile=" + venMobile
				+ ", venAddress=" + venAddress + ", loc=" + loc + "]";
	}
}
