package com.app.provider;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.model.Customer;
import com.app.model.Item;

import com.app.service.ICustomerService;
import com.app.service.IItemService;

import com.app.util.JsonUtil;
import com.app.validator.CustomerValidator;

@Component
@Path("/Item")
public class ServiceProvider {

	@Autowired
	private ICustomerService custService;
	@Autowired
	private CustomerValidator custValidator;
	@Autowired 
	private JsonUtil util;
	@Autowired
	private IItemService itemService;
	
	
	@POST
	@Path("/body")
	public String ItemServiceProvider(@HeaderParam("userName") String uname, @HeaderParam("password") String pwd,
			@HeaderParam("token") String token, String strJson) {

		/**
		 * Checking User Name , Password,token empty or not
		 */
		if (uname == null || "".equals(uname.trim())) {
			return "Username shold not be empty";
		}
		if (pwd == null || "".equals(pwd.trim())) {
			return "Password should not be empty";
		}
		if (token == null || "".equals(token.trim())) {
			return "Token should not be empty";
		}
		if (strJson == null || "".equals(strJson.trim())) {
			return "Body should not be empty";
		}
		/**
		 * Checking user name exist or not call Customer Service Method
		 */
		Customer cust=custService.getCustomerByEmail(uname);
		if ( cust== null) {
			return "UserName Not  Exist";
		}
		/**
		 * Check password and token are Valid are not
		 * And also check Customer type
		 * 
		 */
		if(!custValidator.isCustomerTypeSeller(cust))
		{
			return "InValid Seller Type....";
		}
			if(!custValidator.isPwdAndTokenId(pwd, token, cust)){
			return "InValid Password and Token";
		}
		/**
		 * Convert JsonFormat data into object
		 *and set customerId into ItemModule 
		 */
		
		Object obj=util.jsonToObject(strJson, Item.class);
		if(obj==null){
			return "InValid Item type";
		}
		Item item=(Item)obj;
		item.setCustId(cust.getCustId());
		//Save Item into Database
		itemService.savaItem(item);
	
		
		return "Data Save In Database sucessfully  with ID::"+cust.getCustId();
	}

}
