package com.app.dao;

import java.util.List;

import com.app.model.Vendor;

public interface IVendorDao {

	public int saveVendor(Vendor ven);
	public void deleteVendor(int venId);
	public List<Vendor> getAllVendors();
	
	public Vendor getVendorById(int venId);
	public void updateVendor(Vendor ven);
	
	public boolean isEmailExisted(String venEmail);
	public boolean isMobileExisted(long venMobile);
}
