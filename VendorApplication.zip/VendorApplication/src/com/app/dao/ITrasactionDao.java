package com.app.dao;

import com.app.model.Transaction;

public interface ITrasactionDao {
	
	public int saveTransaction(Transaction txn);

}
