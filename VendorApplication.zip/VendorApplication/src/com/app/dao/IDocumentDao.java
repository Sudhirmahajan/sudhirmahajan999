package com.app.dao;

import java.util.List;

import com.app.model.Document;

public interface IDocumentDao {

	public void saveData(Document doc);
	public List<Document> getDataFileAndName();
	public Document getDocumentById(int fileId);
	public void deleteDocument(int id);
}
