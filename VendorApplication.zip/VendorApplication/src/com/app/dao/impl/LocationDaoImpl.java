package com.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.ILocationDao;
import com.app.model.Location;
import com.app.model.Vendor;



@Repository
public class LocationDaoImpl implements ILocationDao {

	private static final String GET_LOCTYPE_COUNT="Select locType ,count(locType) from "+Location.class.getName()+" group by locType";
	private static final String IS_LOCATION_NAME_EXISTED="from Location where locName=?";
	private static final String IS_LOCID_EXISTED="from Vendor ven join ven.loc as loc where loc.locId=?";
	@Autowired
	private HibernateTemplate ht;
	
	@Override
	public int saveLocation(Location loc) {
	
		return  (Integer)ht.save(loc);
	}
@Override
public List<Location> getAllLocs() {
	
	return ht.loadAll(Location.class);
}

@Override
public void deleteLocById(int locId) {
ht.delete(new Location(locId));
}
@Override
public Location getLocationById(int locId) {
	
	return ht.get(Location.class,locId);
}
@Override
public void updateLocation(Location loc) {
ht.update(loc);
}

@Override
public List<Object[]> getLocTypeByCount() {

	List<Object[]> list=ht.find(GET_LOCTYPE_COUNT);
	return list;
}

@Override
public boolean isLocationNameExisted(String locName) {

	/*
	 * List<Location> list=ht.find(IS_LOCATION_NAME_EXISTED, locName);
	 * 
	 * return (list!=null && list.size()>0);
	 */
	boolean flag=false;
	
	List<Location> list=ht.find(IS_LOCATION_NAME_EXISTED, locName);
	if(list!=null && list.size()>0){
		flag=true;
	}
	return flag;
}

@Override
public boolean isDeletedLocationIdExisted(int locId) {
	boolean flag=false;
	 List<Vendor> list=ht.find(IS_LOCID_EXISTED, locId);
	if(list!=null&&list.size()>0){
		flag=true;
	}
	return flag;
}
}
