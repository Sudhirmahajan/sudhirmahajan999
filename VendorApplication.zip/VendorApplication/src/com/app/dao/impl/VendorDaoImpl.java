package com.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.IVendorDao;
import com.app.model.Vendor;

@Repository
public class VendorDaoImpl implements IVendorDao {

	private static final String IS_EMAIL_EXIST="select venEmail from Vendor where venEmail=? ";
	private static final String IS_MOBILE_EXIST="select venMobile from Vendor where venMobile=? ";
	
	@Autowired
	private HibernateTemplate ht;

	@Override
	public int saveVendor(Vendor ven) {
		return (Integer) ht.save(ven);
	}

	@Override
	public void updateVendor(Vendor ven) {
		ht.update(ven);
	}

	@Override
	public void deleteVendor(int venId) {
		ht.delete(new Vendor(venId));
	}

	@Override
	public Vendor getVendorById(int venId) {
		return ht.get(Vendor.class, venId);
	}

	@Override
	public List<Vendor> getAllVendors() {
		return ht.loadAll(Vendor.class);
	}

	@Override
	public boolean isEmailExisted(String venEmail) {
		boolean flag=false;
		List<Vendor> list=ht.find(IS_EMAIL_EXIST, venEmail);
		if(list!=null && list.size()>0){
			flag=true;
		}
		return flag;
	}
	@Override
	public boolean isMobileExisted(long venMobile) {
		boolean flag=false;
		List<Vendor> list=ht.find(IS_MOBILE_EXIST, venMobile);
		if(list!=null && list.size()>0){
			flag=true;
		}
		return flag;
	}
	
}//class
