package com.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.ICustomerDao;
import com.app.model.Customer;
import com.app.model.Item;
import com.app.model.Transaction;


@Repository
public class CustomerDaoImpl implements ICustomerDao {
	/**
	 * Create Query for perform CURD operation
	 */
	private static final String IS_EMAIL_EXIST=" from Customer where custEmail=? ";
	private static final String GET_CUSTOMER_BY_EMAIL="from Customer where custEmail=?";
	private static final String GET_ALL_ITEM_BY_CUSTID="from Item where custId=?";
	private static final String GET_TXN_BY_CUSTID="from Transaction where custId=?";
	
	@Autowired
	private HibernateTemplate ht;
	
	@Override
	public int saveCustomer(Customer cust) {
		
		return (Integer)ht.save(cust);
	}

	@Override
	public List<Customer> loadAllCustomer() {
		
		return ht.loadAll(Customer.class);
	}

	@Override
	public void deleteCustById(int custId) {
		
		ht.delete(new Customer(custId));
	}

	@Override
	public Customer getCustById(int custId) {
		return ht.get(Customer.class, custId);
	}

	@Override
	public void updateCustomer(Customer cust) {
	ht.update(cust);	
	}
	/**
	 * @return List<Customer> if email are exist
	 * For Item Module
	 */
	@Override
	public List<Customer> getCustomerByEmail(String custEmail) {
		List<Customer> listCust=ht.find(GET_CUSTOMER_BY_EMAIL, custEmail);
		return listCust;
	}
	
/**
 * 	Server side Validation
 * 	@return Email Exist Or Not
 */
	@Override
	public boolean isEmailExisted(String custEmail) {
		boolean flag=false;
		List<Customer> list=ht.find(IS_EMAIL_EXIST, custEmail);
		System.out.println(list.size());
		if(list!=null && list.size()>0){
			flag=true;
		}
		return flag;
	}
	
	/**
	 * @return List of Item
	 * Read all Item of customer id
	 */
	
	@Override
	public List<Item> loadAllItemByCustomerId(int custId) {
		
		return ht.find(GET_ALL_ITEM_BY_CUSTID, custId);
	}

	/**
	 * @return List of Transaction
	 * Read all Transaction of customer id
	 */

	@Override
	public List<Transaction> loadTxnByCustomerId(int custId) {
		return ht.find(GET_TXN_BY_CUSTID, custId);
	}
}
