package com.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.IUserDao;
import com.app.model.User;

@Repository
public class UserDaoImpl implements IUserDao {

	private static final String GET_USER_BY_USERNAME="from User where (userEmail=? or userContact=?) and userType=?";
	private static final String GET_USER_BY_EMAIL="from User where userEmail=? ";
	
	
	
	@Autowired
	private HibernateTemplate ht;
	
	/**
	 * @return userId
	 * Save User Details into Database table
	 */
	@Override
	public int saveUser(User user) {
		return (Integer)ht.save(user);
	}
	
	/**
	 * @return List Of User
	 * get all User Details from Database table email or mobile no.
	 */

	@Override
	public List<User> getUserByUserName(String uname ,String userType) {
		return ht.find(GET_USER_BY_USERNAME, uname,uname,userType);
	}

	/**
	 * @return ListAllUser
	 * get all User Details from Database table
	 */
	@Override
	public List<User> getAllUser() {
		return ht.loadAll(User.class);
	}
	
	/**
	 * 
	 *Change User status into Database table
	 */
	
	@Override
	public void changeStatus(int uid,int status) {
		User entity= ht.get(User.class, uid);
		if(status==1){
		entity.setStatus(0);
		}
		else{
			entity.setStatus(1);
		}
		ht.saveOrUpdate(entity);
	}//method
	
	/**
	 * @return User
	 * get  User Details from Database table by Id
	 */	
	@Override
	public User getUserById(int uid) {
		return ht.get(User.class, uid);
	}
	
	/**
	 * @return User
	 * get  User Details from Database table by email
	 */	
	@Override
	public List<User> getUserByEmail(String email) {
		return ht.find(GET_USER_BY_EMAIL, email);
	}
	
	/**
	 * 
	 *Change User Password into Database table
	 */
@Override
	public String chanPassword(int uid, String pwd) {
	User entity= ht.get(User.class, uid);
	entity.setUserPwd(pwd);
	ht.saveOrUpdate(entity);
	return entity.getUserEmail();
	}
}
