package com.app.dao;

import java.util.List;

import com.app.model.User;

public interface IUserDao {
	
public int saveUser(User user);
public List<User> getUserByUserName(String uname,String userType);
public List<User> getAllUser();

public User getUserById(int uid); 
public void changeStatus(int uid,int status);
public List<User> getUserByEmail(String email); 

public String chanPassword(int uid,String pwd);
}
