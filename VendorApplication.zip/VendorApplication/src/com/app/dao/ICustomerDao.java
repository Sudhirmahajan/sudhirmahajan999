package com.app.dao;

import java.util.List;

import com.app.model.Customer;
import com.app.model.Item;
import com.app.model.Transaction;

public interface ICustomerDao {

	public int saveCustomer(Customer cust);
	public List<Customer> loadAllCustomer();
	public void deleteCustById(int custId);
	
	public Customer getCustById(int custId);
	public void updateCustomer(Customer cust);

	public List<Item> loadAllItemByCustomerId(int custId);
	public List<Transaction> loadTxnByCustomerId(int custId);
	
	public List<Customer> getCustomerByEmail(String custEmail);
	
	public boolean isEmailExisted(String custEmail);
	
}
