package com.app.service;

import com.app.model.Item;

public interface IItemService {

	public int savaItem(Item item);
}
