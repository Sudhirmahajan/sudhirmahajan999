package com.app.service;

import com.app.model.Transaction;

public interface ITransactionService {

	public int saveTransaction(Transaction txn);
}
