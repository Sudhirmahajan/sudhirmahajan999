package com.app.service;

import java.util.List;

import com.app.model.User;

public interface IUserService {	
	public int saveUser(User user);

	public User getUserByUserName(String uname,String userType);
	public List<User> getAllUser();
	public void changeStatus(int uid,int status);
	public User getUserById(int uid); 
	public List<User> getUserByEmail(String email); 

	public String chanPassword(int uid, String pwd);
}
