package com.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IDocumentDao;
import com.app.model.Document;
import com.app.service.IDocumentService;
@Service
public class DocumentServiceImpl implements IDocumentService {

	@Autowired
	private IDocumentDao dao;
	
	@Override
	public void saveData(Document doc) {
	dao.saveData(doc);
	}

	@Override
	public List<Document> getDataFileAndName() {
		
		return dao.getDataFileAndName();
	}

	@Override
	public Document getDocumentById(int fileId) {
	
		return dao.getDocumentById(fileId);
	}

	@Override
	public void deleteDocument(int id) {
dao.deleteDocument(id);
	}
}
