package com.app.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.ICustomerDao;
import com.app.model.Customer;
import com.app.model.Item;
import com.app.model.Transaction;
import com.app.service.ICustomerService;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	private ICustomerDao dao;
	
	@Override
	public int saveCustomer(Customer cust) {
	
		return dao.saveCustomer(cust) ;
	}

	@Override
	public List<Customer> loadAllCustomer() {
		List<Customer> listCust=dao.loadAllCustomer();
		Collections.sort(listCust);
		return listCust;
	}

	@Override
	public void deleteCustById(int custId) {
	dao.deleteCustById(custId);
	}

	@Override
	public Customer getCustById(int custId) {
		
		return dao.getCustById(custId);
	}

	@Override
	public void updateCustomer(Customer cust) {
		dao.updateCustomer(cust);
	}

	/**
	 * For Item Module
	 * return Customer Object
	 */
	public Customer getCustomerByEmail(String custEmail) {
		Customer cust=null;
		List<Customer> listCust=null;
		//create Empty ArrayList
		listCust=new ArrayList<>();
		//call DAO Method
		listCust=dao.getCustomerByEmail(custEmail);
		if(listCust!=null&&listCust.size()>0){
			cust=listCust.get(0);
		
		}
		return cust;
	};
	
	@Override
	public boolean isEmailExisted(String custEmail) {
		return dao.isEmailExisted(custEmail);
	}
	
	@Override
	public List<Item> loadAllItemByCustomerId(int custId) {
		return dao.loadAllItemByCustomerId(custId);
	}
@Override
public List<Transaction> loadTxnByCustomerId(int custId) {
	return dao.loadTxnByCustomerId(custId);
}
}
