package com.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.ITrasactionDao;
import com.app.model.Transaction;
import com.app.service.ITransactionService;

@Service
public class TransactionServiceImpl implements ITransactionService {

	@Autowired
	private  ITrasactionDao dao;

	@Override
	public int saveTransaction(Transaction txn) {
		return dao.saveTransaction(txn);
	}

}
