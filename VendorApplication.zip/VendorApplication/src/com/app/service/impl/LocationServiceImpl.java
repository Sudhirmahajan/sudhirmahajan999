package com.app.service.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.ILocationDao;
import com.app.model.Location;
import com.app.service.ILocationService;

@Service
public class LocationServiceImpl implements ILocationService {

	@Autowired
	private ILocationDao dao;

	@Override
	public int saveLocation(Location loc) {
		return dao.saveLocation(loc);
	}

	@Override
	public List<Location> getAllLocs() {
		List<Location> listLoc = dao.getAllLocs();
		Collections.sort(listLoc);
		return listLoc;
	}

	@Override
	public void deleteLocById(int locId) {
		dao.deleteLocById(locId);
	}

	@Override
	public Location getLocationById(int locId) {
		return dao.getLocationById(locId);
	}

	@Override
	public void updateLocation(Location loc) {
		dao.updateLocation(loc);
	}

	@Override
	public List<Object[]> getLocTypeByCount() {
		List<Object[]> list=dao.getLocTypeByCount();
		return list;
	}

@Override
	public boolean isLocationNameExisted(String locName) {
	
		return dao.isLocationNameExisted(locName);
	}
@Override
public boolean isDeletedLocationIdExisted(int locId) {
	return dao.isDeletedLocationIdExisted(locId);
}
	
}//class
