package com.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IUserDao;
import com.app.model.User;
import com.app.service.IUserService;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserDao dao;
	
	/**
	 * Save Operation perform using DAO object
	 */
	@Override
	public int saveUser(User user) {
		return dao.saveUser(user);
	}

	/**
	 * Get User Details by userName
	 */
	@Override
	public User getUserByUserName(String uname,String userType) {
		List<User> userList=null;
		User user=null;
		//call dao method having userName
		userList=dao.getUserByUserName(uname,userType);
		if(userList!=null&&userList.size()>0){
			user=userList.get(0);		
		}
		return user;
	}

	/**
	 * Get All User
	 */
	@Override
	public List<User> getAllUser() {
		return dao.getAllUser();
	}
	@Override
	public void changeStatus(int uid,int status) {
	dao.changeStatus(uid,status);	
	}
	
	/**
	 * Get  User by calling DAO
	 */
@Override
	public User getUserById(int uid) {
		return dao.getUserById(uid);
	}

/**
 * Get  User by calling DAO
 */
@Override
public List<User> getUserByEmail(String email) {
		return dao.getUserByEmail(email);
}

/**
 * 
 *Change User Password by DAO
 */

@Override
public String chanPassword(int uid, String pwd) {
	
	return dao.chanPassword(uid, pwd);
}
}
