function VenFormValidation(){
	var flag=true;
	var name=/^[A-Za-z ]{2,15}$/;
	var email=/^[a-zA-Z0-9.]+[@][a-z]+[.]?[a-z]*[.][a-z]{2,4}$/;
	var mobile=/^[7-9][0-9]{9}$/;
	var contact=/^[A-Z0-9a-z ]{3,40}$/;
	
	document.getElementById("venNameErr").innerHTML="";
	document.getElementById("venMailErr").innerHTML="";
	document.getElementById("venMblErr").innerHTML="";
	document.getElementById("venAddrErr").innerHTML="";
	document.getElementById("venLocErr").innerHTML="";
	
	if(!(document.venForm.venName.value.match(name))){
		document.getElementById("venNameErr").innerHTML="InValid Name Entered";
		flag= false;
	}
	if(!(document.venForm.venEmail.value.match(email))){
		document.getElementById("venMailErr").innerHTML="InValid Email Entered";
		flag= false;
	}
	if(!(document.venForm.venMobile.value.match(mobile))){
		document.getElementById("venMblErr").innerHTML="InValid Mobile Number Entered";
		flag= false;
	}
	if(!(document.venForm.venAddress.value.match(contact))){
		document.getElementById("venAddrErr").innerHTML="InValid Address Entered";
		flag= false;
	}
	if(document.venForm.locId.value=="-1"){
		document.getElementById("venLocErr").innerHTML="InValid Location Type";
		flag= false;
	}
	return flag;
	}