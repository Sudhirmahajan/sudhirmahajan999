function  passwordFormValidation(){
flag=true;
document.getElementById("passNotMatch").innerHTML="";
currPass=document.passwordName.currpwd.value;
newPass=document.passwordName.pwd.value;
conPass=document.passwordName.pwd1.value;
 var n = conPass.localeCompare(newPass);
if(n>="1"){
		document.getElementById("passNotMatch").innerHTML="New Password  and Confirm Password not Match";
		flag= false;
	}
	return flag;
}
