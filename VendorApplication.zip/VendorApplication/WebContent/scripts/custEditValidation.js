function custRegValidation(){
	var name=/^[A-Za-z ]{2,15}$/;
	var email=/^[a-zA-Z0-9.]+[@][a-z]+[.]?[a-z]*[.][a-z]{2,4}$/;
	var contact=/^[A-Z0-9a-z ]{3,40}$/;
	var flag=true;
	
	document.getElementById("custNameErr").innerHTML=""
	document.getElementById("custMailErr").innerHTML="";
	document.getElementById("custTypeErr").innerHTML="";
	document.getElementById("custAddrErr").innerHTML="";
	document.getElementById("custLocErr").innerHTML="";
	
	if(!(document.custForm.custName.value.match(name))){
		document.getElementById("custNameErr").innerHTML="InValid Name Entered"
		flag=false;
	}
	if(!(document.custForm.custEmail.value.match(email))){
		document.getElementById("custMailErr").innerHTML="InValid Email Entered";
		flag= false;
	}
	if(document.custForm.custType.value=="-1"){
		document.getElementById("custTypeErr").innerHTML="You Must Choose Customer Type";
		flag= false;
	}
	if(!(document.custForm.custAdd.value.match(contact))){
		document.getElementById("custAddrErr").innerHTML="InValid Address Entered";
		flag= false;
	}
	if(document.custForm.locId.value=="-1"){
		document.getElementById("custLocErr").innerHTML="InValid Location Type";
		flag= false;
	}
	return flag;
}
