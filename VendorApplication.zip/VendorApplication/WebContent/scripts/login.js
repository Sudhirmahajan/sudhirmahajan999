function validateform(){  
var name=document.myform.userName.value;  
var password=document.myform.pwd.value;  
document.getElementById("uName").innerHTML = "";
  document.getElementById("Pwd").innerHTML = "";
  document.getElementById("typeErr").innerHTML="";
if (name==null || name==""){  
  //alert("Name can't be blank");  
  document.getElementById("uName").style.color="Red";
  document.getElementById("uName").innerHTML="User Name Should Be Required";
  myform.uname.focus();
  return false;  
}else if(password==null||password==""){  
  //alert("Password must be at least 6 characters long.");
  document.getElementById("Pwd").style.color="Red";
  document.getElementById("Pwd").innerHTML="Password Should Be Required";
  myform.pwd.focus();  
  return false;  
  }  
  if(document.myform.type.value=="-1"){
		document.getElementById("typeErr").style.color="Red";
		document.getElementById("typeErr").innerHTML="You Must Choose Admin Type";
		return false;
	}
}  