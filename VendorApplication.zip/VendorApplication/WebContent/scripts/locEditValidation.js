function LocFormValidation(){
	var flag=true;
	var name=/^[A-Z ]{3,18}$/;
	var pin=/^[1-9][0-9]{5}$/;
	var contact=/^[A-Z0-9a-z ]+$/;
	var process=/^[A-Z]{1,3}[0-9a-z]{3,10}$/;
	
	document.getElementById("locNameErr").innerHTML="";
	//document.getElementById("locTypeErr").innerHTML="";
	document.getElementById("locPinErr").innerHTML="";
	document.getElementById("locShipErr").innerHTML="";
	document.getElementById("locConErr").innerHTML="";
	document.getElementById("locProErr").innerHTML="";
	document.getElementById("locTranErr").innerHTML="";
	
	if(!(document.locForm.locName.value.match(name))){
		document.getElementById("locNameErr").innerHTML="InValid Name Enter";
		flag= false;
	}

	if(!(document.locForm.pincode.value.match(pin))){
		document.getElementById("locPinErr").innerHTML="InValid Pin Code Enter";
		flag= false;
	}
	if(document.locForm.shippingType.value=="-1"){
		document.getElementById("locShipErr").innerHTML="InValid Shipping Type";
		flag= false;
	}
		if(!(document.locForm.contactDetail.value.match(contact))){
		document.getElementById("locConErr").innerHTML="InValid Address Enter";
		flag= false;
	}
	if(!(document.locForm.processCode.value.match(process))){
		document.getElementById("locProErr").innerHTML="InValid Process Code Enter";
		flag= false;
	}
	if(document.locForm.transportType[0].checked==false &&document.locForm.transportType[1].checked==false &&document.locForm.transportType[2].checked==false ){
		document.getElementById("locTranErr").innerHTML="InValid Transport Type";
		flag= false;
	}	 
	return flag;
}
