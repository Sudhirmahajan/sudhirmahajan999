function  passFormValidation() {
flag=true;
document.getElementById("passNotMatch").innerHTML="";
newPass=document.passName.pwd.value;
conPass=document.passName.pwd1.value;
 var n = conPass.localeCompare(newPass);
if(n>="1"){
		document.getElementById("passNotMatch").innerHTML="New Password  and Confirm Password not Match";
		flag= false;
	}
	return flag;
}
